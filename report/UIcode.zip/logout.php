<?php
session_start();
session_destroy();

header("Location: ft5_81_form\index.html");