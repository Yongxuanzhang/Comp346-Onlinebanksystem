<?php  
$mysqli = mysqli_connect("localhost","root","pwd") or die("cannt connet"); 
?>