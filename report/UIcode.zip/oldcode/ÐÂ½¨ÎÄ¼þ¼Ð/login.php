<?php

　　header("Content-type:text/html;charset=utf-8");
echo"链接数据库成功";
$link=mysqli_connect("localhost","root","123456");

if($link)

{
	echo"链接数据库成功";
  $select=mysqli_select_db("login",$link);

  if($select)

  {
echo"xuanze数据库成功";
    if(isset($_POST["subl"]))

    {

      $name=$_POST["usernamel"];

      $password=$_POST["passwordl"];

      if($name==""||$password=="")//判断是否为空

      {

        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."请填写正确的信息！"."\"".")".";"."</script>";

        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."http://127.0.0.1:8080/login.html"."\""."</script>";

        exit;

      }

      $str="select password from register where username="."'"."$name"."'";

      mysqli_query('SET NAMES UTF8');20       $result=mysqli_query($str,$link);

      $pass=mysqli_fetch_row($result);

      $pa=$pass[0];

      if($pa==$password)//判断密码与注册时密码是否一致

      {

        echo"登录成功！";

        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."http://127.0.0.1:8080/success.html"."\""."</script>";

      }

      {  

        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."登录失败！"."\"".")".";"."</script>";

        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."http://127.0.0.1:8080/login.html"."\""."</script>";

      }

    }

     

  }

}

?>