<?php
print phpinfo();

?>