### 简单的PHP注册登录Demo

### 配置数据库

1. 执行sql脚本 `init.php` 创建所需的数据库和表
2. 配置 `database.json` 填上root密码

### 运行

在本地服务器上浏览器打开index.php的页面即可