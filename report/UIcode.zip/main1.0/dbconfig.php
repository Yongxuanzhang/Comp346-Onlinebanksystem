<?php
define("HOST","eec353.encs.concordia.ca");
define("USER","eec353_2");
define("PASS","2018comp");
define("DBNAME","eec353_2");
